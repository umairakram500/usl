import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'services',
  templateUrl: './services.component.html'
})
export class ServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
