import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'team',
  templateUrl: './team.component.html'
})
export class TeamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
