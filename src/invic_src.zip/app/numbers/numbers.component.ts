import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'numbers',
  templateUrl: './numbers.component.html'
})
export class NumbersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
