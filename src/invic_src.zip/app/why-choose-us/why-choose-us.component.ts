import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'whyChooseUs',
  templateUrl: './why-choose-us.component.html'
})
export class WhyChooseUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
